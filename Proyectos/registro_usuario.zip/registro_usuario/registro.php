<?php
require_once "conectar.php";



if (!empty($_POST)) {
  $usuario = $_POST['usuario'];
  $securepassword = password_hash($_POST['password'], PASSWORD_DEFAULT);
  $correo = $_POST['email'];
  $username = $_POST['username'];

  // validate input
	$valid = true;

  if (empty($usuario)) {
		//$nompError = 'Escribe un nombre de proyecto';
		$valid = false;
	}
	if (empty($securepassword)) {
		//$arError = 'Selecciona area estrategica';
		$valid = false;
	}
	if (empty($correo)) {
		//$nomlError = 'Escribe nombre del lider de proyecto';
		$valid = false;
	}

	if (empty($username)) {
		//$nivError = 'Selecciona categoria del proyecto';
		$valid = false;
  }

/*
	// insert data
	if ($valid) {
     $pdo = Database::connect();
    // We need to check if the account with that username exists.
    if ($stmt = $pdo->prepare('SELECT id, password FROM register WHERE username = ?')) {
      // Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
      $stmt->bindValue($_POST['username'], $_POST['email'],$_POST['usuario']);
      $stmt->execute();

      $stmt->store_result();
      // Store the result so we can check if the account exists in the database.
      if ($stmt->num_rows > 0) {
        // Username already exists
        echo '<div><p>El nombre del usuario existe , por favor escoge otro</p></div>';
      } 
      else {
        
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "INSERT INTO register (id, username, password, email, usuario) VALUES (null, ?, ?, ?, ?)";
        $q = $pdo->prepare($sql);
        $securepassword = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $q->execute(array($correo, $securepassword, $username, $usuario));
        echo '<div><p>YA SIRVEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE</p></div>';
        
	    } $stmt->close();
    }
    Database::disconnect();
} */

if ($valid) {
     $pdo = Database::connect();
     $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
     $sql = "INSERT INTO register (id, username, password, email, id_usuario) VALUES (null, ?, ?, ?, ?)";
     $q = $pdo->prepare($sql);
     $q->execute(array($username, $securepassword, $correo,  $usuario));
     Database::disconnect();
}



}



?>

</body>

</html>

<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="registro1.css">
</head>
<meta charset="UTF-8">

<body>
  <header>
    <table class="encabezado">
      <tr>
        <td><img class="logo" src="logo-expo.svg"></td>
      </tr>
    </table>
  </header>
  <div class="contra">
    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-back-up-double" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
      <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
      <path d="M13 14l-4 -4l4 -4"></path>
      <path d="M8 14l-4 -4l4 -4"></path>
      <path d="M9 10h7a4 4 0 1 1 0 8h-1"></path>
    </svg>
    <span></span>
  </div>
  <form action="registro.php" method="post" autocomplete="off">
    <section class="main">
      <h1>Registro de usuario</h1>
      <table class="registro">
        <tr>
          <td><input type="text" name="username" placeholder="Usuario..." id="username" class="input1" /> </td>
        </tr>
        <tr>
          <td><input type="email" name="email" placeholder="Correo..." id="email" class="input2" /> </td>
        </tr>
        <td><input type="password" name="password" placeholder="Contraseña..." id="password" class="input3" /> </td>
        </tr>
          </tr>
        <td><select name="usuario" class="input3" >
						<option value="">Selecciona usuario</option>
            <?php
						$pdo = Database::connect();
						$query = 'SELECT * FROM usuario';
            foreach ($pdo->query($query) as $row) {
							if ($row['id'] == $usuario) 
								echo "<option selected value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
							else
								echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";
						}
            Database::disconnect();
						?>
            </select></td>
        </tr>
        <tr>
          <td><button class="boton1">Registarme</button></td>
        </tr>
      </table>
  </form>
  </section>





